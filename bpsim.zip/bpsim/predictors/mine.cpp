// mine.cpp — Part B: your own predictor (perceptron, loop, TAGE-style, or a new idea).
//
// Keep ALL state in storage.h objects declared as members below (Register,
// Table, DirectMappedCache, SetAssocCache). No other member variables, statics,
// globals, containers, or heap allocation. Sizes are your choice; bpsim counts
// the bits and the total must stay within 64 Kbit (check with ./bpsim -s mine).
#include "predictor.h"

class MyPredictor : public BranchPredictor {
  static constexpr unsigned HIST_BITS = 12; 
  static constexpr unsigned CTR_INIT = 0;

  static constexpr unsigned BIMOD_ENTRIES = 1u << 12;
  static constexpr unsigned BIMOD_CTR_BITS = 2; 
  static constexpr unsigned BIMOD_THRESH = 1u << (BIMOD_CTR_BITS - 1);   

  static constexpr unsigned CACHE_SETS = 1u << 10;
  static constexpr unsigned CACHE_WAYS = 2;
  static constexpr unsigned CACHE_CTR_BITS = 2;

  static constexpr unsigned CACHE_TAG_BITS = 8; 
  static constexpr bool BIM_UPDATE_ALWAYS = false;
  static constexpr unsigned 

  Register mine_{HIST_BITS, CTR_INIT, Unsigned, "mine_ghr"};
  Table bimod{BIMOD_ENTRIES, BIMOD_CTR_BITS, BIMOD_THRESH, Unsigned, "mine_locphistable"};
  Table tcache{CACHE_SETS, CACHE_WAYS, CACHE_TAG_BITS, CACHE_CTR_BITS, LRU, Unsigned, "mine_tcache"};
  Table ntcache{CACHE_SETS, CACHE_WAYS, CACHE_TAG_BITS, CACHE_CTR_BITS, LRU, Unsigned, "mine_ntcache"};


 public:
  bool predict(uint64_t pc) override {
    const bool bias = bimod.get((pc >> 2) & (BIMOD_ENTRIES - 1)) >= BIMOD_THRESH;
    const SetAssocCache& c = bias ? ntcache : tcache;
    const int way = c.lookup(((pc >> 2) ^ mine_.get() & (CACHE_SETS - 1)), (pc >> 2));
 
    if (way >= 0) return c.read(((pc >> 2) ^ mine_.get()) & (CACHE_SETS - 1), way) >= CACHE_THRESH;  // exception applies
    return bias; 
    (void)pc;
    // return false;
  }

  void update(uint64_t pc, bool taken) override {
    uint64_t bim = (((pc >> 2) ^ mine_.get()) & (BIMOD_ENTRIES - 1));
    uint64_t set = (((pc >> 2) ^ mine_.get()) & (CACHE_SETS - 1));
    uint64_t tag = (pc >> 2);

    const bool bias = bimod.get(bim) >= BIMOD_THRESH;
    SetAssocCache& c = bias? ntcache : tcache;
    const int way = c.lookup(det, tag);

    const bool hit = (way > = 0);
    const bool cachePred = (hit && (c.read(set, way)) >= CACHE_THRESH);

    // bool  shortPred= shorphistTable.get(shortIndex) >= SHORT_THRESH; 
    // bool longPred = lonphistTable.get(longIndex) >= LONG_THRESH;

    if(shortPred != longPred) {
      if(longPred == taken) chooser.inc(bim);
      else chooser.dec(bim);
    } 

    if(hit){
      if(taken) c.inc(set, way);
      else c.dec(set, way);
      c.touch(set, way);
    } else if(taken != bias) {
      c.insert(set, tag, taken? CACHE_THRESH : (CACHE_THRESH - 1))
    }

    mine_.shiftIn(taken);

    (void)pc;
    (void)taken;
  }
};

REGISTER_PREDICTOR("mine", MyPredictor);
