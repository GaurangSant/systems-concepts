// onebit.cpp — Part A: a table of last outcomes, indexed by low-order PC bits.
//
// Keep ALL state in storage.h objects declared as members below (Register,
// Table, DirectMappedCache, SetAssocCache). No other member variables, statics,
// globals, containers, or heap allocation. Sizes are your choice; bpsim counts
// the bits and the total must stay within 64 Kbit (check with ./bpsim -s onebit).
#include "predictor.h"

class OneBitPredictor : public BranchPredictor {
  static constexpr unsigned INDEX_BITS = 1u << 16;
  Table predictor{INDEX_BITS, 1, 0, Unsigned, "one bit"};

 public:
  bool predict(uint64_t pc) override {
    return predictor.get((pc >> 2) % INDEX_BITS);
    
    (void)pc;
    //return false;
  }

  void update(uint64_t pc, bool taken) override {
    predictor.set(((pc >> 2) % INDEX_BITS), taken);
    (void)pc;
    (void)taken;
  }
};

REGISTER_PREDICTOR("onebit", OneBitPredictor);
