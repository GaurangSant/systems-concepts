// gshare.cpp — Part A: global history XOR PC indexes a table of 2-bit counters.
//
// Keep ALL state in storage.h objects declared as members below (Register,
// Table, DirectMappedCache, SetAssocCache). No other member variables, statics,
// globals, containers, or heap allocation. Sizes are your choice; bpsim counts
// the bits and the total must stay within 64 Kbit (check with ./bpsim -s gshare).
#include "predictor.h"

class GsharePredictor : public BranchPredictor {
  static constexpr unsigned INDEX_BITS = 14;              
  static constexpr unsigned HIST_BITS = 14;              
  static constexpr unsigned CTR_BITS = 3;               
  static constexpr unsigned PHT_ENTRIES = 1ull << INDEX_BITS;
  static constexpr unsigned CTR_INIT = 1ll << (CTR_BITS - 1);      
  static constexpr unsigned CTR_THRESH = 1ll << (CTR_BITS - 1);   

  Register ghr_{HIST_BITS, 0, Unsigned, "gshare_ghr"};
  Table pht{PHT_ENTRIES, CTR_BITS, CTR_INIT, Unsigned, "gshare_pht"};


 public:
  bool predict(uint64_t pc) override {
    return pht.get(((pc >> 2) ^ ghr_.get()) & 0x3FFF) >= CTR_THRESH;
    (void)pc;
    // return false;
  }

  void update(uint64_t pc, bool taken) override {
    if (taken) {
      pht.inc(((pc >> 2) ^ ghr_.get()) & 0x3FFF);                    
    }else {
      pht.dec(((pc >> 2) ^ ghr_.get()) & 0x3FFF);
    }
    ghr_.shiftIn(taken);
    (void)pc;
    (void)taken;
  }
};

REGISTER_PREDICTOR("gshare", GsharePredictor);
