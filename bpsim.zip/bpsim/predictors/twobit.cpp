// twobit.cpp — Part A: a table of 2-bit saturating counters, indexed by PC (bimodal).
//
// Keep ALL state in storage.h objects declared as members below (Register,
// Table, DirectMappedCache, SetAssocCache). No other member variables, statics,
// globals, containers, or heap allocation. Sizes are your choice; bpsim counts
// the bits and the total must stay within 64 Kbit (check with ./bpsim -s twobit).
#include "predictor.h"

class TwoBitPredictor : public BranchPredictor {
  static constexpr unsigned INDEX_BITS = 15;
  static constexpr unsigned TOTAL_ENTRIES = 1u << INDEX_BITS;
  Table predictor{TOTAL_ENTRIES, 2, 00, Unsigned, "two bit"};
  
 public:
  bool predict(uint64_t pc) override {
    // return (predictor.get((pc >> 2) % TOTAL_ENTRIES) > 2)? true : false;
    return predictor.get((pc >> 2) % TOTAL_ENTRIES);
    (void)pc;
    return false;
  }

  void update(uint64_t pc, bool taken) override {
    if(taken){
      predictor.inc(uint64_t ((pc >> 2) % TOTAL_ENTRIES)); 
    }else{
      predictor.dec(uint64_t ((pc >> 2) % TOTAL_ENTRIES));   
    }
    
    (void)pc;
    (void)taken;
  }
};

REGISTER_PREDICTOR("twobit", TwoBitPredictor);
