// tournament.cpp — Part A: local + global predictors; 2-bit chooser counters pick one.
//
// Keep ALL state in storage.h objects declared as members below (Register,
// Table, DirectMappedCache, SetAssocCache). No other member variables, statics,
// globals, containers, or heap allocation. Sizes are your choice; bpsim counts
// the bits and the total must stay within 64 Kbit (check with ./bpsim -s tournament).
#include "predictor.h"

class TournamentPredictor : public BranchPredictor {
  static constexpr unsigned HIST_BITS = 12; 
  static constexpr unsigned CTR_INIT = 0;
  static constexpr unsigned LHT_ENTRIES = 1u << 11;
  static constexpr unsigned LHT_BITS = 11;            
  static constexpr unsigned LPHT_ENTRIES = 1u << 11;
  static constexpr unsigned LOCAL_CTR_BITS = 4; 
  static constexpr unsigned LOCAL_THRESH = 1u << (LOCAL_CTR_BITS - 1);   
  static constexpr unsigned GPHT_ENTRIES = 1u << 12;
  static constexpr unsigned GLOBAL_CTR_BITS = 6; 
  static constexpr unsigned GLOBAL_THRESH = 1u << (GLOBAL_CTR_BITS - 1);
  static constexpr unsigned CHOOSER = 1u << 11;
  static constexpr unsigned CHOOSER_CTR_BITS = 4;
  static constexpr unsigned CHOOSER_THRESH = 1u << (CHOOSER_CTR_BITS - 1);

  Register tourmnt_{HIST_BITS, CTR_INIT, Unsigned, "tournament_gshr"};
  Table lochistTable{LHT_ENTRIES, LHT_BITS, CTR_INIT, Unsigned, "tournament_lochistable"};
  Table locphistTable{LPHT_ENTRIES, LOCAL_CTR_BITS, LOCAL_THRESH, Unsigned, "tournament_locphistable"};
  Table globhistTable{GPHT_ENTRIES, GLOBAL_CTR_BITS, GLOBAL_THRESH, Unsigned, "tournament_globphistable"};
  Table chooser{CHOOSER, CHOOSER_CTR_BITS, CHOOSER_THRESH, Unsigned, "tournament_chooser"};

 public:
  bool predict(uint64_t pc) override {
    int index = (pc >> 2) & 0x7FF;
    int locpred = lochistTable.get(index);
    bool locppred = locphistTable.get(locpred) >= LOCAL_THRESH;
    int tourmnt = tourmnt_.get();
    bool globppred = globhistTable.get(tourmnt) >= GLOBAL_THRESH;
    bool selectpred  = chooser.get(index) >= CHOOSER_THRESH; 

    return selectpred? locppred : globppred;    

    (void)pc;
  }

  void update(uint64_t pc, bool taken) override {
    int index = (pc >> 2) & 0x7FF;
    int locpred = lochistTable.get(index);
    bool locppred = locphistTable.get(locpred) >= LOCAL_THRESH;
    int tourmnt = tourmnt_.get();
    bool globppred = globhistTable.get(tourmnt) >= GLOBAL_THRESH;

    if (locppred != globppred) {
      if (globppred == taken)  chooser.dec(index);
      else if (locppred == taken) chooser.inc(index);
    }

    if (taken) {
      locphistTable.inc(locpred); 
      globhistTable.inc(tourmnt);
    }else{
      locphistTable.dec(locpred);
      globhistTable.dec(tourmnt);
    }

    unsigned h = ((locpred << 1) | (taken ? 1u : 0u)) & 0x7FF;
    lochistTable.set(index, h);
    tourmnt_.shiftIn(taken);  

    (void)pc;
    (void)taken;
  }
};

REGISTER_PREDICTOR("tournament", TournamentPredictor);
